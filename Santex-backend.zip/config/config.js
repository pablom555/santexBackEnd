/*
import TOKEN from './config';
* API Football Data
*/
TOKEN = "59c4ef07e594468f84b85218a90285e1";
URL_FOOTBALL = "https://api.football-data.org/v2/competitions";

module.exports = {
    TOKEN,
    URL_FOOTBALL
}